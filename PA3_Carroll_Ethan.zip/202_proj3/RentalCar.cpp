/*This file contains all the codefor my main functions
*
*
*/

#define MAX 256	//string size
#define DFT_YEAR 0
#define DFT_PRICE 0.0
#define DFT_AVAILABLE 0
const char * DFT_MAKE = "NONE";
const char * DFT_MODEL = "NONE"; //above are defaults for the constructors

#include <iostream>
#include <fstream>

#include "my_string.h"
#include "RentalCar.h"
#include "Agency.h"
#include "menu.h"
using namespace std;

RentalCar::RentalCar(){
	m_year = DFT_YEAR;
	setMake(DFT_MAKE);
	setModel(DFT_MODEL);
	m_price = DFT_PRICE;
	m_available = DFT_AVAILABLE;
}

RentalCar::RentalCar(int* year, char* make, char* model, float* price, bool *available, const bool *avalable){
	m_year = *year;
	setMake(make);
	setModel(model);
	m_price = *price;
	m_available = *available;
}

void RentalCar::print() const{
	cout << m_year <<" "<< m_make<<" " << m_model<<", $" << m_price<<" per day, Available: " <<boolalpha<< m_available<< endl;
}

float RentalCar::estimateCost(const int &dayCount){
	float cost;
	cost = dayCount * m_price;
	return cost;
}

void RentalCar::setYear(int *year){
	m_year = *year;
}

void RentalCar::setMake(const char* make){
	myStringCopy(m_make, make);
}

void RentalCar::setModel(const char *model){
	myStringCopy(m_model, model);
}

void RentalCar::setPrice(float *price){
	m_price = *price;
}

void RentalCar::setAvailable(bool available){
	m_available = available;
}

const int RentalCar::getYear() const{
	return m_year;
}
const char * RentalCar::getMake() const{
	return m_make;
}

const char * RentalCar::getModel() const{
	return m_model;
}

const float RentalCar::getPrice() const{
	return m_price;
}

const bool RentalCar::getAvailable() const{
	return m_available;
}

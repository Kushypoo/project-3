/*This file contains all the source code for my main functions 
*Does not include source code for string functions
*
*/
#define MAX 256	//string size
#define DFT_YEAR 0
#define DFT_PRICE 0.0
#define DFT_AVAILABLE 0


#include <iostream>
#include <fstream>

#include "my_string.h"
#include "RentalCar.h"
#include "Agency.h"
#include "menu.h"

using namespace std;

void userMenuPrompt(){	//This function disaplays a menu and takes user input. Acts as a hub for all the other fucntions
	struct RentalAgency arr[3];
	RentalAgency *arr_pt = NULL; //This is the main pointer that gets passed to most functions
	arr_pt = arr;
	char userInput;	//input is in car because char input to int sets value to zero
	do{
	cout << "Enter a Menu Option\n*******MENU*******\n1 - Inport Car and Agency Info\n2 - View Car and Agency Info\n3 - Estimate Rental Cost\n";
	cout << "4 - Find the Cheapest Available Car\n5 - Reserve a Car\n6 - Exit Program\n"; 
	cin >> userInput;
		switch(userInput){
			case '1':
				readCars(arr_pt);
			break;
			case '2':
				printAgenciesToTerminal(arr_pt);
			break;	
			case '3':
				estimateRentalCost(arr_pt);
			break;
			case '4':
				findCheapestRental(arr_pt);
			break;
			case '5':
				reserveCarandRefreshList(arr_pt);
			break;
			case '6':
				return;
			break;
				
			default:
				cerr << "ERROR: INPUT OPTION IS NOT AVAILABLE\n";
			break;
		} 	
	
		
	}while(userInput != '6'); //repetive but prevents some bugs
	return;
}

void readCars(struct RentalAgency *arr){	//This function reads info from an input file
	int yearT;	//Below are temp variable that make it much easier to scan from file
	char makeT[MAX];
	char modelT[MAX];
	float priceT;
	bool availableT;
	char inputFile[MAX];	
	cout << "Enter the Name of Your Input File(name.extension)\n";	//File input function
	cin >> inputFile;
	ifstream stream(inputFile);
	if(!stream.is_open()){
		cerr << "ERROR: COULD NOT OPEN FILE\n";	//Error and return statemtn for file open failure
		return;
	}	
	char temp[6];	//this temp array is made specificlaly for streaming the zip code
	for(int i = 0; i < 3; ++i){
		stream >> arr->name >> temp; //inputs rental agency information
		char *pnt;	//these two pointers are created to iterate from 1-5 for two arrays
		pnt = temp;
		int *pnt2;
		pnt2 = arr->zipcode;
		for(int i = 0; i < 5;++i){
			*pnt2 = *pnt -48;	//-48 to convert from char ASCII to int
			pnt++;	//These two lines incrimentthe pointer position
			pnt2++;
		} 
		RentalCar * k; //This pointer is for the array of 5 cars info
		k = arr->inventory;
		for(int j = 0; j < 5; ++j){	
			stream >> yearT >> makeT >> modelT >> priceT >> availableT;//streams into temps first
			k->setYear(&yearT);
			char *m;	//creates one more pointerfor the char arrays
			m = makeT;
			k->setMake(m); 
			m = modelT;	//reuses the char pointer
			k->setModel(m);		
			k->setPrice(&priceT);	//passes by reference
			k->setAvailable(availableT);	//sets data through temps
			++k;
		}
		++arr;
	}
	stream.close();	//closes input stream
}

void printAgenciesToTerminal(struct RentalAgency *arr){	//This function prints index values, agency data and car data to the terminal
	for(int i = 0; i < 3; ++i){
		int* n;
		n = arr->zipcode;
		cout <<endl<<"["<<i<<"]"<< arr->name <<" ";
		for(int b = 0; b < 5;++b){	//This for loop was implented to solve a bug where I could only print the zip adress or the first digit
			cout << *(n);
			++n;
		}
		cout << endl;
		RentalCar * k;	//Pointer for car info
		k = arr->inventory;
		for(int j = 0; j < 5; ++j){
			cout << "["<<j<<"]";	
			k->print();	//prints car through print function one car at a time 
			++k;
		}
		++arr;
	}	
}
void estimateRentalCost(struct RentalAgency *arr){	//This function take userinput for car indexs and day count and estimates a total cost
	int index1, index2, dayCount;
	cout << "What car agency do you want to view?(Enter Index Numner)" << endl;
	cin >> index1;
	cout << "Which car would you like to check the price for?(Enter Index Number)" << endl;
	cin >> index2;
	cout << "How many days are you planning on renting this car for?" << endl;
	cin >>  dayCount;
	arr += index1;	//sets car agency array to correct struct
	RentalCar *c_pnt;	//creates pointer for car data 
	c_pnt = arr->inventory;
	c_pnt += index2;	//sets car array to correct car
	float rental_cost;
	rental_cost = c_pnt->estimateCost(dayCount);	//calls toatl price function
	cout << "For " << dayCount << " days you will pay $"<< rental_cost <<endl;
}

void findCheapestRental(struct RentalAgency *arr){
	float tempPrice;
	float cheapPrice;
	int index;
	cout << endl << "######CHEAPEST CARS######"<< endl;
	for(int i = 0; i < 3; ++i){
		cheapPrice = 99999; //impossibly high number so that it is always exchanged on the first iteration of j
		index = -1;	//resets index to an impossible value
		RentalCar *c_pnt;
		c_pnt = (arr+i)->inventory;
		for(int j = 0; j < 5; ++j){
			tempPrice = (c_pnt + j)->getPrice();
			if(tempPrice < cheapPrice && (c_pnt + j)->getAvailable() == 1 ){ //Tests wether the car is cheaper than the min and available
				cheapPrice = tempPrice;	
				index = j; //saves index value for printing all car values
			}	
		}
		cout << (arr+i)->name << ":" << endl; //Outputs company name
		(c_pnt + index)->print();	//Outputs info for cheapest car
		cout << endl;
	}
}

void reserveCarandRefreshList(struct RentalAgency *arr){
	int index1, index2;
	cout << "What car agency do you want to rent from?(Enter Index Numner)" << endl;
	cin >> index1;
	arr += index1;
	RentalCar *c_pnt;
	c_pnt = arr->inventory;
	cout << "Which car would you like to rent?(Enter Index Number)" << endl;
	cin >> index2;
	c_pnt += index2;
	if((c_pnt->getAvailable()) == 0){
		cerr << "ERROR: CAR IS NOT AVAILABLE FOR RENTAL"<< endl;
		return;
	}
	c_pnt->setAvailable(false);	//Reserves car by setting avialability to false	
	arr -= index1;	//sets index back to zero
	printAgenciesToTerminal(arr);	//Refreshes list
	cout << "SUCCESS! Your car has been reserved!" << endl;	
}

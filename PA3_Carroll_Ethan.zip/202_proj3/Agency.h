/*This file contains the declaration for my rental agency structure
*
*
*/
#ifndef AGENCY_H_
#define AGENCY_H_

struct RentalAgency{	
	char name[MAX];
	int zipcode[5];
	RentalCar inventory[5];
};


#endif

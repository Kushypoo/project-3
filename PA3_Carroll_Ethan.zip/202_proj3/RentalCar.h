/*This file contains thedeclaration for my rental car class
*
*
*/
#ifndef RENTALCAR_H_
#define RENTALCAR_H_

class RentalCar {
	public:
		RentalCar();
		RentalCar(int* year, char* make, char* model, float* price, bool *available, const bool *avalable = DFT_AVAILABLE); //Needs a defualt and non default argument for avialable
		void print() const;
		float estimateCost(const int &dayCount); //REQUIRED PASS BY REFERENCE FUNCTION
		void setYear(int *year);
		void setMake(const char *make);
		void setModel(const char *model);
		void setPrice(float *price);
		void setAvailable(bool available);
		const int getYear() const;
		const char *getMake() const;
		const char *getModel() const;
		const float getPrice() const;
		const bool getAvailable() const;
	private:
		int m_year;
		char m_make[MAX];
		char m_model[MAX];
		float m_price;
		bool m_available;		
};



#endif

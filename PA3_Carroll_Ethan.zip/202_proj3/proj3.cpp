/*This file contains my main finction
*This proggram is designed to use class structure to allow a user to analyse data
*fron many differient types of cars.
*/

#define MAX 256	//string size
#define DFT_YEAR 0
#define DFT_PRICE 0.0
#define DFT_AVAILABLE 0

#include <iostream>
#include <fstream>

#include "my_string.h"
#include "RentalCar.h"
#include "Agency.h"
#include "menu.h"


using namespace std;


int main(){
	userMenuPrompt();
	return 0;
}





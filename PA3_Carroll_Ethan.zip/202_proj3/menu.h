/*This file contains the declaration for my menu functions
*
*
*/
#ifndef MENU_H_
#define MENU_H_

void userMenuPrompt();	
void readCars(struct RentalAgency *arr);
void printAgenciesToTerminal(struct RentalAgency *arr);
void estimateRentalCost(struct RentalAgency *arr);
void findCheapestRental(struct RentalAgency *arr);
void reserveCarandRefreshList(struct RentalAgency *arr);



#endif
